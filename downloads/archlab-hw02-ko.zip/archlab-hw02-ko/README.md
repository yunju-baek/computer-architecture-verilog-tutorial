# HW02 프로세서 구성 모듈

과제 안내는 [assignments/hw02/README.md](assignments/hw02/README.md)에 있다.

선행 학습용 [Verilog 자습서](tutorial/README.md)를 함께 제공한다.

```bash
make package-check
cd assignments/hw02
make setup-check
```
