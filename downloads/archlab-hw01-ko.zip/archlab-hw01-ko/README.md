# HW01 함수 호출과 아키텍처 상태

과제 안내는 [assignments/hw01/README.md](assignments/hw01/README.md)에 있다.

```bash
cd assignments/hw01
make setup-check
```
