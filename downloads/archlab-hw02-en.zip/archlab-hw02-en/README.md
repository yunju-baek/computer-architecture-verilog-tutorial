# HW02 Processor building blocks

The assignment guide is [assignments_en/hw02/README.md](assignments_en/hw02/README.md).

The [Verilog tutorial](tutorial_en/README.md) is included for preparation.

```bash
make package-check
cd assignments_en/hw02
make setup-check
```
