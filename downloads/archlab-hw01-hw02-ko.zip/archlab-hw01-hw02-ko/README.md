# HW01–HW02 학생 배포본

HW01과 HW02의 학생 구현 자료와 Verilog 자습서를 제공한다. HW03·HW04는 주제 소개 단계이다.

[Assignments](assignments/README.md) · [Tutorial](tutorial/README.md)

```bash
make package-check
cd assignments/hw01
make setup-check
```
