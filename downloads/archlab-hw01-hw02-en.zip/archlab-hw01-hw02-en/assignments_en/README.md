# Student assignments: HW01–HW02

HW01 and HW02 are available below. Read each assignment for the implementation, tests, and submission files. Each report has four sections. Each assignment is worth 100 points: implementation 50, verification 30, report 20. Follow the deadline and upload format in the corresponding LMS entry.

| Assignment | Topic | Instructions | LMS post |
|---|---|---|---|
| HW01 | Function calls and architectural state | [README](hw01/README.md) | [LMS announcement](hw01/lms_announcement.md) |
| HW02 | Processor building blocks | [README](hw02/README.md) | [LMS announcement](hw02/lms_announcement.md) |

## Run

Use Python 3.11 or later and GNU Make. HW02 also requires Icarus Verilog. Run `make setup-check` in each assignment directory. Complete the starter code before expecting `make test` to pass. Generate execution evidence and record your work in the report and `integrity.txt`.

Keep the supplied tools and public tests. Record the resources and tools you used, and verify and explain your code and results. Save a separate copy of submission evidence before running `make clean`.

## Later assignment previews

- HW03: Connect processor modules and study data movement and state updates in a single-cycle core.
- HW04: Study data dependencies and execution performance in a pipeline.

These entries describe the topics and learning goals for HW03 and HW04. Implementation files, tests, detailed specifications, and report templates will be provided when each assignment opens.
