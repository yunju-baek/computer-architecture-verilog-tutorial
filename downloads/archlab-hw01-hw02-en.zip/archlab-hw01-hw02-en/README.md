# HW01–HW02 student package

This package contains HW01 and HW02 plus the Verilog tutorial. HW03 and HW04 have topic previews only.

[Assignments](assignments_en/README.md) · [Tutorial](tutorial_en/README.md)

```bash
make package-check
cd assignments_en/hw01
make setup-check
```
