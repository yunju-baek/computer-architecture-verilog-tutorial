# HW01 Function calls and architectural state

The assignment guide is [assignments_en/hw01/README.md](assignments_en/hw01/README.md).

```bash
cd assignments_en/hw01
make setup-check
```
